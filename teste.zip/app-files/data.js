var APP_DATA = {
  "scenes": [
    {
      "id": "0-r0010503_20240416092645",
      "name": "R0010503_20240416092645",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": -1.885907394795078,
        "pitch": 0.05673231296000836,
        "fov": 1.222445190334001
      },
      "linkHotspots": [
        {
          "yaw": -1.8405236750481038,
          "pitch": 0.27665584535165166,
          "rotation": 0,
          "target": "1-r0010504_20240416092710"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-r0010504_20240416092710",
      "name": "R0010504_20240416092710",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": 1.0222045024630404,
        "pitch": 0.18021305017208,
        "fov": 1.222445190334001
      },
      "linkHotspots": [
        {
          "yaw": 0.4265959562288,
          "pitch": 0.35408922060985226,
          "rotation": 0,
          "target": "0-r0010503_20240416092645"
        },
        {
          "yaw": 1.9609415663639869,
          "pitch": 0.44871599017017694,
          "rotation": 0,
          "target": "2-r0010505_20240416092757"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-r0010505_20240416092757",
      "name": "R0010505_20240416092757",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": -0.7411577101908264,
        "pitch": 0.27933022776675287,
        "fov": 1.222445190334001
      },
      "linkHotspots": [
        {
          "yaw": -1.6627929597404023,
          "pitch": 0.41152516277263196,
          "rotation": 0,
          "target": "1-r0010504_20240416092710"
        },
        {
          "yaw": -0.18689093758261066,
          "pitch": 0.5224595547201432,
          "rotation": 0,
          "target": "3-r0010506_20240416092844"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-r0010506_20240416092844",
      "name": "R0010506_20240416092844",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": -2.7377934757383997,
        "pitch": 0.12923835236883363,
        "fov": 1.222445190334001
      },
      "linkHotspots": [
        {
          "yaw": -3.1027478408694265,
          "pitch": -0.17565282884492106,
          "rotation": 0,
          "target": "2-r0010505_20240416092757"
        },
        {
          "yaw": -2.5706404371869738,
          "pitch": 0.5328909709565561,
          "rotation": 0,
          "target": "4-r0010507_20240416092907"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-r0010507_20240416092907",
      "name": "R0010507_20240416092907",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.3576021399985194,
          "pitch": -0.20314828096405968,
          "rotation": 0,
          "target": "3-r0010506_20240416092844"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "teste",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
